# Salesforce Account API

REST API that exposes CRUD-style operations against Salesforce Accounts and their associated Contacts.

## What it does

| Method | Path                                    | Description                                  |
|--------|-----------------------------------------|----------------------------------------------|
| GET    | /api/v1/accounts                        | List all Accounts (limit/offset pagination)  |
| GET    | /api/v1/accounts/{accountId}            | Retrieve one Account by Salesforce Id        |
| GET    | /api/v1/accounts/search                 | Filter Accounts by email/name/phone/industry |
| POST   | /api/v1/accounts                        | Create a new Account                         |
| POST   | /api/v1/accounts/{accountId}/contacts   | Create a Contact under an Account            |

## Run locally

```bash
mvn clean package
mvn mule:run -Denv=dev -Dsecure.key=<aes-key>
```

Listener binds to `0.0.0.0:8081`.

## Environments

`src/main/resources/properties/<env>.yaml` + `<env>-secure.yaml`. Activate with `-Denv=dev|test|prod`.

| Key                              | File         | Description                            |
|----------------------------------|--------------|----------------------------------------|
| http.host / http.port            | <env>.yaml   | HTTP listener bind                     |
| salesforce.username              | <env>.yaml   | Salesforce user                        |
| salesforce.url                   | <env>.yaml   | Salesforce SOAP endpoint               |
| salesforce.account.emailField    | <env>.yaml   | Custom email field (default Email__c)  |
| salesforce.password              | <env>-secure | Encrypted Salesforce password          |
| salesforce.security.token        | <env>-secure | Encrypted Salesforce security token    |

Secrets are encrypted by the Mule Secure Properties module (AES/CBC) and decrypted at runtime via `${secure::...}`.

## Error envelope

All errors return the same JSON shape:

```json
{
  "errorCode":     "SF_NOT_FOUND",
  "errorMessage":  "Account with id 001xx000003DGbYAAW not found",
  "correlationId": "9b8e1d2c-7f4a-4b3c-8e2d-1a2b3c4d5e6f",
  "timestamp":     "2026-06-11T03:20:00Z"
}
```

APIKit auto-maps 400 / 404 / 405 / 406 / 415 / 501. Transient Salesforce errors (`SALESFORCE:CONNECTIVITY`, `SALESFORCE:RETRY_HEADER_DETECTED`) are retried via `until-successful` (3 attempts, 2s spacing) and surface as 502 if still failing.

## TBDs

- The Client ID Enforcement policy is declared in the RAML securitySchemes but is enforced at the Anypoint gateway / API Manager edge, not in this app. Deployer must attach the policy.
- `salesforce.account.emailField` defaults to `Email__c`; override per env if the Salesforce org uses a different field.
