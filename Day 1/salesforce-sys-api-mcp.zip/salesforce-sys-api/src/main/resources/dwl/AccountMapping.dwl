%dw 2.0

fun toAccountJson(acc) = {
  id: acc.Id,
  name: acc.Name,
  phone: acc.Phone,
  website: acc.Website,
  industry: acc.Industry,
  email: acc.Email__c,
  billingAddress: {
    street: acc.BillingStreet,
    city: acc.BillingCity,
    state: acc.BillingState,
    postalCode: acc.BillingPostalCode,
    country: acc.BillingCountry
  },
  createdDate: acc.CreatedDate,
  lastModifiedDate: acc.LastModifiedDate
}

fun toAccountSObject(json) = {
  Name:              json.name,
  Phone:             json.phone,
  Website:           json.website,
  Industry:          json.industry,
  Email__c:          json.email,
  BillingStreet:     json.billingAddress.street,
  BillingCity:       json.billingAddress.city,
  BillingState:      json.billingAddress.state,
  BillingPostalCode: json.billingAddress.postalCode,
  BillingCountry:    json.billingAddress.country
}
