# Salesforce Account API — MCP server

The Mule app `salesforce-sys-api` now exposes its REST operations as **MCP
tools** over Streamable HTTP, **without changing the existing REST API**.

- **MCP endpoint:** `http://localhost:8081/salesforce/mcp`
- **REST API (unchanged):** `http://localhost:8081/api/v1/...`
- Defined in `src/main/mule/salesforce-account-api-mcp.xml`
- Connector: `com.mulesoft.connectors:mule-mcp-connector:1.2.0` (added to `pom.xml`)

## Tools

Each tool **reuses the existing implementation sub-flow in-process via
`flow-ref`** (no HTTP hop, no duplicated logic). The tool maps its MCP
arguments into `attributes.queryParams` / `attributes.uriParams` / `payload`
(via an `ee:transform`) exactly as the REST router would, then calls the
sub-flow.

| Tool | Reuses sub-flow (same logic as REST op) | Required args |
|------|------------------------------------------|---------------|
| `list-accounts`   | `get-accounts-subflow`      (`GET /accounts`)                       | — (optional `limit`, `offset`) |
| `get-account`     | `get-account-by-id-subflow` (`GET /accounts/{accountId}`)           | `accountId` |
| `search-accounts` | `search-accounts-subflow`   (`GET /accounts/search`)               | one of `name`/`email`/`phone`/`industry` |
| `create-account`  | `create-account-subflow`    (`POST /accounts`)                      | `name` |
| `create-contact`  | `create-contact-subflow`    (`POST /accounts/{accountId}/contacts`) | `accountId`, `lastName` |

Each tool ships a detailed description and a JSON Schema for its inputs (see
the `<mcp:parameters-schema>` blocks in the XML).

## Run the app
Deploy `salesforce-sys-api` from Anypoint Studio (or `mvn ... mule:deploy`).
On startup you should see the MCP endpoint mounted at `/salesforce/mcp` on the
same `8081` listener as the REST API.

Quick check (Streamable HTTP returns an SSE/JSON response to an initialize):
```bash
curl -i -X POST http://localhost:8081/salesforce/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"curl","version":"1"}}}'
```

## Integrate with Claude Desktop
Claude Desktop launches MCP servers over stdio, so we bridge to the HTTP
endpoint with `mcp-remote` (requires Node.js / `npx`).

Merge `claude_desktop_config.json` (in this folder) into your Claude Desktop
config file:
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "salesforce-account-api": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "http://localhost:8081/salesforce/mcp"]
    }
  }
}
```
Restart Claude Desktop; the `salesforce-account-api` tools appear in the tools menu.

## Integrate with Claude Code (native HTTP — no bridge needed)
```bash
claude mcp add --transport http salesforce-account-api http://localhost:8081/salesforce/mcp
```
or add to `.mcp.json` in your project:
```json
{
  "mcpServers": {
    "salesforce-account-api": {
      "type": "http",
      "url": "http://localhost:8081/salesforce/mcp"
    }
  }
}
```

> Change `localhost:8081` to your deployed host/port (e.g. a CloudHub URL) when
> running outside local Studio.
